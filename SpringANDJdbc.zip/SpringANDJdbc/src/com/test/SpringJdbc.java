package com.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class SpringJdbc {
	private int EmpId;
	private String EmpName;
	private String EmpAddress;

	public int getEmpId() {
		return EmpId;
	}

	public void setEmpId(int empId) {
		EmpId = empId;
	}

	public String getEmpName() {
		return EmpName;
	}

	public void setEmpName(String empName) {
		EmpName = empName;
	}

	public String getEmpAddress() {
		return EmpAddress;
	}

	public void setEmpAddress(String empAddress) {
		EmpAddress = empAddress;
	}

	@Override
	public String toString() {
		return "SpringJdbc [EmpId=" + EmpId + ", EmpName=" + EmpName + ", EmpAddress=" + EmpAddress + "]";
	}
	Connection con;
	public void DatabaseConnection() throws Exception
	{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employee?useSSL=false","root","root");
			System.out.println("Connection Done");
		
	}
	public void SaveDataIntoDB() throws SQLException
	{
		PreparedStatement stmt=con.prepareStatement("INSERT INTO employee.emp1(EmployeeId,EmployeeName,EmployeeAddress) VALUES (?,?,?)");
		stmt.setInt(1, 3);
		stmt.setString(2, "Pikay");
		stmt.setString(3, "Darauli");
		int i=stmt.executeUpdate();
		stmt.close();
		System.out.println("Insertion done using prepared statment and total "+i+" row affected");
	}
	public void CloseConnection() throws SQLException
	{
		con.close();
		System.out.println("connection closed");
	}

}