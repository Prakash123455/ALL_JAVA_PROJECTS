package com.test;

import java.util.Scanner;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

public class TestDriverClass {

	public static void main(String[] args) {

		Resource res = new ClassPathResource("Spring.xml");
		BeanFactory fact = new XmlBeanFactory(res);
		SpringJdbc ed = (SpringJdbc) fact.getBean("sp1");

		Scanner sc = new Scanner(System.in);
		for (int i = 0; i < 3; i++) {
			System.out.println("Enter 1 to create BD Connection " + "\n" + "Enter 2 to Save data to Employee.emp1 table"
					+ "\n" + "Enter 3 to close connection");
			int key = sc.nextInt();
			switch (key) {
			case 1:
				try {
					ed.DatabaseConnection();
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;

			case 2:
				try {
					ed.SaveDataIntoDB();
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;

			case 3:
				try {
					ed.CloseConnection();
				} catch (Exception e) {
					e.printStackTrace();
				}
				break;

			default:
				break;
			}
		}
	}

}
