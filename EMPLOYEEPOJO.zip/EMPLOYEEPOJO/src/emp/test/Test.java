package emp.test;

import java.util.HashMap;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class Test {
	public static void main(String[] args) {
		Employee c1 = new Employee();
		c1.setEmpAddress("Tamilnadu");
		c1.setEmpID(900);
		c1.setEmpName("Ra1");
		Employee c2 = new Employee();
		c2.setEmpAddress("Bangalore");
		c2.setEmpID(901);
		c2.setEmpName("Ra2");
		Employee c3 = new Employee();
		c3.setEmpAddress("Delhi");
		c3.setEmpID(902);
		c3.setEmpName("Ra3");
		Employee c4 = new Employee();
		c4.setEmpAddress("Assam");
		c4.setEmpID(903);
		c4.setEmpName("Ra4");

		HashMap HmSouthcity = new HashMap<>();
		HmSouthcity.put("1", c1);
		HmSouthcity.put("2", c2);
		HashMap HmNorthcity = new HashMap<>();
		HmNorthcity.put("3", c3);
		HmNorthcity.put("4", c4);
		
		HashMap HmCity=new HashMap<>();
		HmCity.put("500", HmSouthcity);
		HmCity.put("600", HmNorthcity);
		
		Set set = HmCity.entrySet();
		Iterator iterator = set.iterator();
		while(iterator.hasNext()) 
		{
			Map.Entry Mentry = (Map.Entry)iterator.next();
			//System.out.println("key is: "+ Mentry.getKey() + " & Value is: "+Mentry.getValue());
			Set set1 = ((HashMap) Mentry.getValue()).entrySet();
			Iterator iterator1 = set1.iterator();
			while(iterator1.hasNext())
			{
				Map.Entry Mentry1 = (Map.Entry)iterator1.next();
				System.out.println("key is: "+ Mentry1.getKey() + " & Value is: "+Mentry1.getValue());
			}
		}
	}
}
