package emp.test;

public class Employee 
{
private int EmpID;
private String EmpName;
private String EmpAddress;
public int getEmpID() {
	return EmpID;
}
public void setEmpID(int empID) {
	EmpID = empID;
}
public String getEmpName() {
	return EmpName;
}
public void setEmpName(String empName) {
	EmpName = empName;
}
public String getEmpAddress() {
	return EmpAddress;
}
public void setEmpAddress(String empAddress) {
	EmpAddress = empAddress;
}
@Override
public String toString() {
	return "EmppID=" + EmpID + ", EmpName=" + EmpName + ", EmpAddress=" + EmpAddress;
}

}
