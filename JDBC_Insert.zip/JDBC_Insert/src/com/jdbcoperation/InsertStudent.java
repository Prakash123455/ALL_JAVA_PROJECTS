package com.jdbcoperation;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class InsertStudent {
	public static void main(String[] args) {

		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student?useSSL=false","root","root");
			Statement stmt=con.createStatement();
			stmt.execute("INSERT INTO student.stud(StudentID,StudentName,StudentAddress)VALUES (5,'xxxx','yyyyy')");
			System.out.println("Insertion done");
			stmt.close();
			con.close();
		} catch (Exception e) 
		{
			System.out.println("sql exception");
		}
	}
}
