package com.student;

public class StudentDetails {
	@Override
	public String toString() 
	{
		return "StudentDetails StudID=" + StudID + ", StudName=" + StudName + "";
	}

	private int StudID;
	private String StudName;

	public int getStudID() {
		return StudID;
	}

	public void setStudID(int studID) {
		StudID = studID;
	}

	public String getStudName() {
		return StudName;
	}

	public void setStudName(String studName) {
		StudName = studName;
	}
	
	public void Display()
	{
		System.out.println("Student id is:- "+StudID +" Student Name is:-"+StudName);
	}
}
