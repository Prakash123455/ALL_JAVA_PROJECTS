package com.student;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Test2 {

	public static void main(String[] args) {

		StudentDetails c1=new StudentDetails();
		c1.setStudID(100);
		c1.setStudName("Prakash");
		
		StudentDetails c2=new StudentDetails();
		c2.setStudID(101);
		c2.setStudName("Akashay");
		
		StudentDetails c3=new StudentDetails();
		c3.setStudID(102);
		c3.setStudName("Anshu");
		
		StudentDetails c4=new StudentDetails();
		c4.setStudID(103);
		c4.setStudName("Rahul");
		
		ArrayList MHStud=new ArrayList ();
		MHStud.add(c1);
		MHStud.add(c2);
		ArrayList GJStud =new ArrayList();
		GJStud.add(c3);
		GJStud.add(c4);
		
		ArrayList CountryStud =new ArrayList<>();
		CountryStud.add(MHStud);
		CountryStud.add(GJStud);
			
		 Iterator it = CountryStud.iterator();

		    while(it.hasNext())
		        {
		        Iterator itr = ((ArrayList) it.next()).iterator();
		        
		        while(itr.hasNext())
		            {
		            System.out.println(itr.next());
		            }
		        }
	}

}
