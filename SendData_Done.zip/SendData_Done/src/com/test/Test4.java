package com.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.test.Student;

public class Test4 {

	public static void main(String[] args) {
		Resource res=new ClassPathResource("Spring.xml");
		BeanFactory fact=new XmlBeanFactory(res);
		Student  sed=(Student) fact.getBean("student");
		sed.Display();
	}

}
