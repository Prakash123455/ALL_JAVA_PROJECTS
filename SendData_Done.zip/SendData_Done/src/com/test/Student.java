package com.test;

import java.util.List;

public class Student {

	private int Sid;
	private String Sname;
	private Address Sadd;
	private List Slist;
	
	public Student(int sid, String sname, Address sadd, List slist) {
		super();
		Sid = sid;
		Sname = sname;
		Sadd = sadd;
		Slist = slist;
	}

	@Override
	public String toString() {
		return "Student [Sid=" + Sid + ", Sname=" + Sname + ", Sadd=" + Sadd + ", Slist=" + Slist + "]";
	}
	
	public void Display()
	{
		System.out.println("studentid is "+Sid+" StudentName"+Sname+" StudentAddress "+Sadd);
		for(Object ob:Slist)
		{
			System.out.println(ob);
		}
	}
}
