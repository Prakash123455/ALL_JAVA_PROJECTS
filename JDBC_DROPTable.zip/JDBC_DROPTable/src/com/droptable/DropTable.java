package com.droptable;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DropTable {
public static void main(String[] args) {
	try {
		
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employee?useSSL=false","root","root");
		Statement stmt=con.createStatement();
		stmt.executeUpdate("DROP TABLE employee.emp");
		System.out.println("Table Droped");
		stmt.close();
		con.close();
	} catch (Exception e) 
	{
		System.out.println("sql exception");
	}
}
}
