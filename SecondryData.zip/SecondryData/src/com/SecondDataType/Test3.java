package com.SecondDataType;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;



public class Test3 {
	public static void main(String[] args) {
	
	Resource res=new ClassPathResource("Spring2.xml");
	BeanFactory fact=new XmlBeanFactory(res);
	StudentDetails  sed=(StudentDetails) fact.getBean("sp2");
	sed.Display();
}
}
