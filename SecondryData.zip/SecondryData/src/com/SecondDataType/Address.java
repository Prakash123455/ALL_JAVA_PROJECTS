package com.SecondDataType;

public class Address {
	private String Saddress;
	private String Sdistrict;
	@Override
	public String toString() {
		return "Address Studentaddress=" + Saddress + ", Studentdistrict=" + Sdistrict + ", Studentcountry=" + Scountry + "]";
	}

	private String Scountry;

	public String getSdistrict() {
		return Sdistrict;
	}

	public void setSdistrict(String sdistrict) {
		Sdistrict = sdistrict;
	}

	public String getScountry() {
		return Scountry;
	}

	public void setScountry(String scountry) {
		Scountry = scountry;
	}

	public String getSaddress() {
		return Saddress;
	}

	public void setSaddress(String saddress) {
		Saddress = saddress;
	}

}
