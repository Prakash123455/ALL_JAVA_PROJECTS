package com.datastore;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.naming.spi.DirStateFactory.Result;

public class CollegeStudentDataStore {
	public static void main(String[] args) {

		try {

			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student?useSSL=false","root","root");
			Statement stmt=con.createStatement();
			ResultSet res=stmt.executeQuery("Select * from stud");
			while(res.next())
			{
				System.out.println(res.getInt(1)+"  "+res.getString(2)+"  "+res.getString(3));
			}
			//System.out.println("connection done");
			stmt.close();
			con.close();
		} catch (Exception e) 
		{
			System.out.println("sql exception");
		}
	}
}