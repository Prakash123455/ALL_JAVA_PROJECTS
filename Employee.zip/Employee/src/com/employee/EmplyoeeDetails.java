package com.employee;

import java.util.List;

public class EmplyoeeDetails 
{
	private int EmpID;
	private String EmpName;
	private List Country; 
	
	
	public List getCountry() {
		return Country;
	}
	public void setCountry(List country) {
		Country = country;
	}
	public int getEmpID() {
		return EmpID;
	}
	public void setEmpID(int empID) {
		EmpID = empID;
	}
	public String getEmpName() {
		return EmpName;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	
	public void Display()
	{
		System.out.println("Employee Id is:-"+EmpID +"Employee Name is:-"+EmpName);
		for(Object obj:Country)
		{
			System.out.println(obj);
		}
	}
	
}
