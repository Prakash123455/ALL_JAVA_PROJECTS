package com.Example.EmployeeDetails;

public class EmployeeSalaryDetails {
	private int GrossSalary;
	private int BaseSalary;
	private int VariableSalary;

	public EmployeeSalaryDetails(int grossSalary, int baseSalary, int variableSalary) {
		super();
		GrossSalary = grossSalary;
		BaseSalary = baseSalary;
		VariableSalary = variableSalary;
	}

	@Override
	public String toString() {
		return "EmployeeSalaryDetails [GrossSalary=" + GrossSalary + ", BaseSalary=" + BaseSalary + ", VariableSalary="
				+ VariableSalary + "]";
	}
}
