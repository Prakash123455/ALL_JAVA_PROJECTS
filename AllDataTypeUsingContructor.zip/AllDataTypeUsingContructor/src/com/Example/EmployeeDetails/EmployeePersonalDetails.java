package com.Example.EmployeeDetails;

import java.util.List;
import java.util.Map;

public class EmployeePersonalDetails {
	private int EmpID;
	private String EmpName;
	private String EmpAddress;
	private EmployeeSalaryDetails Empesd;
	
	private List Emplist;
	private Map Empmap;
	
	

	public EmployeePersonalDetails(int empID, String empName, String empAddress, EmployeeSalaryDetails empesd,
			List emplist, Map empmap) {
		super();
		EmpID = empID;
		EmpName = empName;
		EmpAddress = empAddress;
		Empesd = empesd;
		Emplist = emplist;
		Empmap = empmap;
	}



	@Override
	public String toString() {
		return "EmployeePersonalDetails [EmpID=" + EmpID + ", EmpName=" + EmpName + ", EmpAddress=" + EmpAddress
				+ ", Empesd=" + Empesd + ", Emplist=" + Emplist + ", Empmap=" + Empmap + "]";
	}
	
	public void Display1()
	{
		System.out.println("EmpID=" + EmpID + ", EmpName=" + EmpName + ", EmpAddress=" + EmpAddress+ ", Empesd=" + Empesd + ", Emplist=" + Emplist + ", Empmap=" + Empmap);
	}
}
