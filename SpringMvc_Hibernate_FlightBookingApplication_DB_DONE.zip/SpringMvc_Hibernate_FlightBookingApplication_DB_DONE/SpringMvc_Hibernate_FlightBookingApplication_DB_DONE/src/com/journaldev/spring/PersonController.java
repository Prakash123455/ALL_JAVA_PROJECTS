package com.journaldev.spring;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.journaldev.spring.model.AvailableFlight;
import com.journaldev.spring.model.Flight;
import com.journaldev.spring.model.PassengerDetails;
import com.journaldev.spring.model.Payment;
import com.journaldev.spring.model.User;
import com.journaldev.spring.model.UserRegistration;
import com.journaldev.spring.service.PersonService;

@Controller
public class PersonController {

	private PersonService personService;

	@Autowired(required = true)
	@Qualifier(value = "personService")
	public void setPersonService(PersonService ps) 
	{
		this.personService = ps;
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView Home(HttpServletRequest req, HttpServletResponse res) {
		ModelAndView mv = new ModelAndView("home_1");
		return mv;
	}

	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView loginPost(HttpServletRequest req, HttpServletResponse res, @ModelAttribute("user") User user,
			@ModelAttribute("flight") Flight flight) {
		ModelAndView mv = null;
		// validate the user
		try {
			boolean isValidUser = personService.isValidUser(user);
			System.out.println("USER VALID OR NOT:-" + isValidUser);
			if (isValidUser) {
				//System.out.println("User Login Successful");
				req.setAttribute("loggedInUser", user.getUsername());
				
				ArrayList fid = new ArrayList();
				ArrayList source = new ArrayList();
				ArrayList destination = new ArrayList();
				ArrayList typeOftrip = new ArrayList();
				ArrayList departuredate = new ArrayList();
				ArrayList arrivaldate = new ArrayList();
				List<Flight> FlightDetailsList = personService.getSourcelist();
				
				for (int i = 0; i < FlightDetailsList.size(); i++) {
					Flight flightlist = FlightDetailsList.get(i);
					source.add(flightlist.getSource());
					destination.add(flightlist.getDestination());
					typeOftrip.add(flightlist.getTypeOftrip());
					departuredate.add(flightlist.getDeparturedate());
					arrivaldate.add(flightlist.getArrivaldate());
					System.out.println("source is----" + flightlist.getSource());
				}
				mv = new ModelAndView("searchflight_2");
				mv.addObject("flight", flight);
				mv.addObject("sourcelist", source);
				mv.addObject("destinationlist", destination);
				mv.addObject("arrivaldatelist", arrivaldate);

			} else {
				req.setAttribute("loginfailed", "Please enter coreect login id");
				ModelAndView mv1 = new ModelAndView("home_1");
				return mv1;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return mv;
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView Registerpost(HttpServletRequest req, HttpServletResponse res,
			@ModelAttribute("userregistraion") UserRegistration userregistraion) {
		ModelAndView mv = null;
		// validate the user Registration
		if(userregistraion.getPassword().equals(userregistraion.getRePassword()))
		{
		try {
			boolean isSaveData = personService.isSaveData(userregistraion);
			System.out.println("DATA IS SAVED OR NOT:-" + isSaveData);
			if (isSaveData) {
				req.setAttribute("regsiterd", "User registerd successfully..!!");
				mv = new ModelAndView("home_1");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		}else
		{
			req.setAttribute("registraionfailed", "Password and re-password does not matched");
			ModelAndView mv1 = new ModelAndView("home_1");
			return mv1;
		}
		return mv;
	}

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy");
		sdf.setLenient(true);
		binder.registerCustomEditor(Date.class, new CustomDateEditor(sdf, true));
	}

	@RequestMapping(value = "/flight", method = RequestMethod.POST)
	public ModelAndView addFlight(HttpServletRequest req, HttpServletResponse res,@ModelAttribute("flight") Flight flight,@ModelAttribute("availavleflight") AvailableFlight availavleflight) 
	{
		List<AvailableFlight> FlightL3=new ArrayList();
		
		ModelAndView mv = new ModelAndView("flightdetails_3");
		List<AvailableFlight> FlightL1 = personService.getAvailableFlightlist();
		
		for (int j = 0; j < FlightL1.size(); j++) 
		{
			AvailableFlight FlightL2 = FlightL1.get(j);
			
			String sdate1=req.getParameter("departuredate");//date from jsp page
			String sdate2=FlightL2.getDate();//getting date from DB
			String ssource1=req.getParameter("source");
			String ssource2=FlightL2.getSouce();
			String sdestination1=req.getParameter("destination");
			String sdestination2=FlightL2.getDestination();	
			if (sdate1.equals(sdate2) && ssource1.equals(ssource2) &&sdestination1.equals(sdestination2) ) 
			{
				FlightL3.add(FlightL2);
			}
			
		}
		mv.addObject("flightavailavlelist",FlightL3);
		return mv;

	}

	@RequestMapping(value = "/bookflight/{FlightName}/{FlightArrival}/{FlightDeparture}/{FlightPrice}", method = RequestMethod.GET)
	public ModelAndView bookFlight(HttpServletRequest req, HttpServletResponse res,			
			@PathVariable("FlightName") String FlightName, @PathVariable("FlightArrival") String FlightArrival,
			@PathVariable("FlightDeparture") String FlightDeparture, @PathVariable("FlightPrice") String FlightPrice) {
		
		req.setAttribute("FlightName", "FlightName");
		req.setAttribute("FlightArrival", "FlightArrival");
		req.setAttribute("FlightDeparture", "FlightDeparture");
		req.setAttribute("FlightPrice", "FlightPrice");

		ModelAndView mv = new ModelAndView("bookedflight_4");
		return mv;
	}
	
	@RequestMapping(value = "/passenger/{FlightName}/{FlightArrival}/{FlightDeparture}/{FlightPrice}",method=RequestMethod.POST)
	public ModelAndView addPassenger(HttpServletRequest req, HttpServletResponse res,@ModelAttribute("flight") PassengerDetails passengerdetails,
			@ModelAttribute("FlightName") String FlightName,@ModelAttribute("FlightArrival") String FlightArrival,@ModelAttribute("FlightDeparture") String FlightDeparture,@ModelAttribute("FlightPrice") String FlightPrice) 
	{
		ModelAndView mv = null;
		// validate the user Registration
		try {
			boolean isSavePassenger = personService.isSavePassenger(passengerdetails);
			if (isSavePassenger) 
			{
				req.setAttribute("FlightName", FlightName);
				req.setAttribute("FlightArrival", FlightArrival);
				req.setAttribute("FlightDeparture", FlightDeparture);
				req.setAttribute("FlightPrice", FlightPrice);
				req.setAttribute("PassengerAdded", "passengerdetails");
				mv = new ModelAndView("payment_5");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mv;
	}

	@RequestMapping(value = "/congrats",method=RequestMethod.POST)
	public ModelAndView DisplayCongrats(HttpServletRequest req, HttpServletResponse res,@ModelAttribute("payment")Payment payment) 
	{
		System.out.println("congratulation ...!!! icket is booked");
		ModelAndView mv=new ModelAndView("congrats_6");
		return mv;
	}
}
