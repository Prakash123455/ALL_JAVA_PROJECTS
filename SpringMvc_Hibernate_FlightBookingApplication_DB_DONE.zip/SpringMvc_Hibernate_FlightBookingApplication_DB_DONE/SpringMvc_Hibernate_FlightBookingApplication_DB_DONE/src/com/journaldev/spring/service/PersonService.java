package com.journaldev.spring.service;

import java.util.ArrayList;
import java.util.List;

import com.journaldev.spring.model.AvailableFlight;
import com.journaldev.spring.model.Flight;
import com.journaldev.spring.model.PassengerDetails;
import com.journaldev.spring.model.User;
import com.journaldev.spring.model.UserRegistration;

public interface PersonService {
	
	
	public boolean isValidUser(User user);
	public boolean isSaveData(UserRegistration userregistraion);
	public List<Flight> getSourcelist();
	public List<AvailableFlight> getAvailableFlightlist();
	public boolean isSavePassenger(PassengerDetails passengerdetails);

	
	
}
