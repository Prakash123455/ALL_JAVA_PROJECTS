package com.journaldev.spring.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.journaldev.spring.dao.PersonDAO;
import com.journaldev.spring.model.AvailableFlight;
import com.journaldev.spring.model.Flight;
import com.journaldev.spring.model.PassengerDetails;
import com.journaldev.spring.model.User;
import com.journaldev.spring.model.UserRegistration;

@Service
public class PersonServiceImpl implements PersonService {
	
	private PersonDAO personDAO;

	public void setPersonDAO(PersonDAO personDAO) 
	{
		this.personDAO = personDAO;
	}
	
	
	@Override
	@Transactional
	public boolean isValidUser(User user)
	{
		return this.personDAO.isValidUser(user);
	}
	
	@Override
	@Transactional
	public boolean isSaveData(UserRegistration userregistraion)
	{
		return this.personDAO.isSaveData( userregistraion);
	}
	
	@Override
	@Transactional
	public List<Flight> getSourcelist()
	{
		return this.personDAO.getSourcelist();
	}
	
	@Override
	@Transactional
	public List<AvailableFlight> getAvailableFlightlist()
	{
		return this.personDAO.getAvailableFlightlist();
	}
	
	@Override
	@Transactional
	public boolean isSavePassenger(PassengerDetails passengerdetails)
	{
		return this.personDAO.isSavePassenger( passengerdetails);
	}
	

}
