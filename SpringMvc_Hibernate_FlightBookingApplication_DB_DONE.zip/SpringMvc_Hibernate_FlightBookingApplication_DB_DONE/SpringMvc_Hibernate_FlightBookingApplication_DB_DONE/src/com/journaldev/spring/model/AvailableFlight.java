package com.journaldev.spring.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "AVAILABLEFLIGHT")
public class AvailableFlight {
	
	@Id
	@Column(name = "fid")
	private int fid;
	private String date;
	private String flightname;
	private String arrival;
	private String departure;
	private String price;
	private String source;
	private String destination;
	public int getFid() {
		return fid;
	}
	public void setFid(int fid) {
		this.fid = fid;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getFlightname() {
		return flightname;
	}
	public void setFlightname(String flightname) {
		this.flightname = flightname;
	}
	public String getArrival() {
		return arrival;
	}
	public void setArrival(String arrival) {
		this.arrival = arrival;
	}
	public String getDeparture() {
		return departure;
	}
	public void setDeparture(String departure) {
		this.departure = departure;
	}
	public String getPrice() {
		return price;
	}
	public void setPrice(String price) {
		this.price = price;
	}
	public String getSouce() {
		return source;
	}
	public void setSouce(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	@Override
	public String toString() {
		return "AvailableFlight [fid=" + fid + ", date=" + date + ", flightname=" + flightname + ", arrival=" + arrival
				+ ", departure=" + departure + ", price=" + price + ", souce=" + source + ", destination=" + destination
				+ "]";
	}
	
}
