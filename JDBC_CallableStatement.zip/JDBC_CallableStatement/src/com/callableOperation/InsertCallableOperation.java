package com.callableOperation;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;



public class InsertCallableOperation {
	public static void main(String[] args) {

		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student?useSSL=false","root","root");
			CallableStatement cstmt=con.prepareCall("call insertoperation(?,?,?)");
			cstmt.setInt(1, 7);
			cstmt.setString(2, "Mohit");
			cstmt.setString(3, "Chennai");
			int i=cstmt.executeUpdate();
			System.out.println("Insertion done using Callable statment and total "+i+" row affected");
			cstmt.close();
			con.close();
		} catch (Exception e) 
		{
			System.out.println("sql exception");
		}
}
}
