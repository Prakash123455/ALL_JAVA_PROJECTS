package com.journaldev.spring;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.journaldev.spring.model.Person;
import com.journaldev.spring.model.User;
import com.journaldev.spring.model.UserRegistration;
import com.journaldev.spring.service.PersonService;

@Controller
public class PersonController {

	private PersonService personService;

	@Autowired(required = true)
	@Qualifier(value = "personService")
	public void setPersonService(PersonService ps) {
		this.personService = ps;
	}

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView Home(HttpServletRequest req, HttpServletResponse res) {
		ModelAndView mv = new ModelAndView("home");
		return mv;
	}

	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login(HttpServletRequest req, HttpServletResponse res, User user) {
		ModelAndView mv = new ModelAndView("login");
		mv.addObject("user", user);
		return mv;
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ModelAndView loginPost(HttpServletRequest req, HttpServletResponse res, @ModelAttribute("user") User user,
			@ModelAttribute("person") Person person) {
		ModelAndView mv = null;
		// validate the user
		try {
			boolean isValidUser = personService.isValidUser(user);
			System.out.println("USER VALID OR NOT:-" + isValidUser);
			if (isValidUser) 
			{
				System.out.println("User Login Successful");
				req.setAttribute("loggedInUser", user.getUsername());
				mv = new ModelAndView("person");
				mv.addObject("person", person);
			}
			else
			{
				req.setAttribute("loginfailed", "Please enter coreect login id");
				ModelAndView mv1 = new ModelAndView("home");
			
				return mv1;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return mv;
	}

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView Register(HttpServletRequest req, HttpServletResponse res) {
		ModelAndView mv = new ModelAndView("register");
		return mv;
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView Registerpost(HttpServletRequest req, HttpServletResponse res,
			@ModelAttribute("userregistraion") UserRegistration userregistraion) {
		ModelAndView mv = null;
		// validate the user Registration
		try {
			boolean isSaveData = personService.isSaveData(userregistraion);
			System.out.println("DATA IS SAVED OR NOT:-" + isSaveData);
			if (isSaveData) 
			{
				req.setAttribute("regsiterd", "User registerd successfully..!!");
				mv = new ModelAndView("home");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mv;
	}

	// it will just return the persons details as list
	
	@RequestMapping(value = "/persons", method = RequestMethod.GET)
	public String listPersons(Model model) {
		model.addAttribute("person", new Person());
		model.addAttribute("listPersons", this.personService.listPersons());
		return "person";
	}

	

	// For add and update person both
	@RequestMapping(value = "/person/add", method = RequestMethod.POST)
	public String addPerson(@ModelAttribute("person") Person p) {

		if (p.getId() == 0) {
			// new person, add it
			this.personService.addPerson(p);
		} else {
			// existing person, call update
			this.personService.updatePerson(p);
		}

		return "redirect:/persons";

	}

	@RequestMapping("/remove/{id}")
	public String removePerson(@PathVariable("id") int id) {

		this.personService.removePerson(id);
		return "redirect:/persons";
	}

	@RequestMapping("/edit/{id}")
	public String editPerson(@PathVariable("id") int id, Model model) {
		model.addAttribute("person", this.personService.getPersonById(id));
		model.addAttribute("listPersons", this.personService.listPersons());
		return "person";
	}

}
