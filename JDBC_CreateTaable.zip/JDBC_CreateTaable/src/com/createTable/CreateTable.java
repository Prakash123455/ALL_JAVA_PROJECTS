package com.createTable;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class CreateTable {
public static void main(String[] args) {

	try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee?useSSL=false", "root","root");
		Statement stmt = con.createStatement();
		 int res= stmt.executeUpdate("CREATE TABLE employee.emp(FName VARCHAR(255),FID int);");
		System.out.println("Table created "+ res );
		stmt.close();
		con.close();
	} catch (Exception e) {
		System.out.println("sql exception");
	}
}
}
