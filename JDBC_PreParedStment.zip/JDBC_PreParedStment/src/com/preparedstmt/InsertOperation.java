package com.preparedstmt;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

public class InsertOperation {
	public static void main(String[] args) {

		try {
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/student?useSSL=false","root","root");
			PreparedStatement stmt=con.prepareStatement("INSERT INTO student.stud(StudentID,StudentName,StudentAddress) VALUES (?,?,?)");
			stmt.setInt(1, 5);
			stmt.setString(2, "Mohit");
			stmt.setString(3, "Chennai");
			int i=stmt.executeUpdate();
			System.out.println("Insertion done using prepared statment and total "+i+" row affected");
			stmt.close();
			con.close();
		} catch (Exception e) 
		{
			System.out.println("sql exception");
		}
	}
}
